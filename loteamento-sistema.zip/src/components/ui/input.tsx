export function Input({ ...props }: any) {
  return <input className="border p-2 rounded w-full" {...props} />;
}