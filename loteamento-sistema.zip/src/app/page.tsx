import LotesDashboard from "../components/LotesDashboard";

export default function Home() {
  return <LotesDashboard />;
}